# A sample test package

count_in_list: Function that count the number of elements in a list 
