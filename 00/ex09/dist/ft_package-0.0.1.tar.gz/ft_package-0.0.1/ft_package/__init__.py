# ft_package/__init__.py
from .ft_package import count_in_list
